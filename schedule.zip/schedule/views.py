from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import auth
from .models import TaskModel, NewEventModel
from datetime import date,datetime
from datetime import timedelta
# Create your views here.
def demo(request):
    return render(request,'index.html')

def signup(request):
    return render(request,'sign up.html')

def register(request):
    if request.method == 'POST':
        username=request.POST['name']
        password=request.POST['password']
        try:
            user = User.objects.get(username=username)
            return redirect("/")
        except User.DoesNotExist: 
            user = User.objects.create_user(username=username,password=password)
            user.save()
            return redirect("/home")
    return render(request,"sign up.html")

def login(request):
    if request.method == 'POST':
        username=request.POST['name']
        password=request.POST['password']
        x = auth.authenticate(username=username,password=password)
        if x is None: 
            return redirect("/signup")
        else:
            return redirect('/home')
    return render(request,"login.html")

def home(request):
    return render (request, 'home.html')

def task_form(request):
    return render(request,"add_task.html")

def add_task(request):
    if request.method=='POST':
        topicname=request.POST['topic_name']
        hours_spent=request.POST['hours_spent']
        level=int(request.POST['easiness'])
        familiarity=int(request.POST['familiar'])
        startDate=request.POST['start_date']
        endDate=request.POST['end_date']
        tm = TaskModel(topic_name=topicname,topic_familiarity=familiarity,topic_difficulty=level,hours_spent=hours_spent,start_date=startDate,end_date=endDate)
        tm.save()
        EF = (level + familiarity)/2
        interval = 1
        for i in range(1,11,1):
            nextinterval = EF * interval
            if nextinterval == 1.5:
                nextinterval = 1
            else:
                nextinterval = int(round(nextinterval))
            interval=nextinterval
            event=datetime.strptime(str(startDate),"%Y-%m-%d").date()
            endDate=datetime.strptime(str(endDate),"%Y-%m-%d").date()
            eventDate=event+timedelta(days=nextinterval)

            if eventDate<=endDate:

                em=NewEventModel(topic_name=topicname,event_date=eventDate)
                em.save()